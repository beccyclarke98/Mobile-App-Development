import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

import HomeScreen from './screens/HomeScreen'
import CreateAccount from './screens/CreateAccount';
import LoginScreen from './screens/LoginScreen';
import LoginAuthenticating from './screens/LoginAuthenticating';
import MainSeeChits from './screens/MainSeeChits';
import PostChitBig from './screens/PostChitBig';
import SearchUserResultList from './screens/SearchUserResultList';
import UsersAccount from './screens/UsersAccount';
import GetFollowersList from './screens/GetFollowersList';
import GetFollowingList from './screens/GetFollowingList';
import EditUserAccount from './screens/EditUserAccount';
import SearchedUserProfile from './screens/SearchedUserProfile';

const AppStackNav = createStackNavigator({
  HomeScreen:
  {
  screen: HomeScreen
  },
  CreateAccount:
  {
    screen:CreateAccount
  },
  LoginScreen:
  {
    screen:LoginScreen
  },
  LoginAuthenticating:
  {
    screen: LoginAuthenticating
  },
  MainSeeChits:
  {
    screen: MainSeeChits
  },
  PostChitBig:
  {
    screen: PostChitBig
  },
  SearchUserResultList:
  {
    screen: SearchUserResultList
  },
  UsersAccount:
  {
    screen: UsersAccount
  },
  GetFollowersList:
  {
    screen: GetFollowersList
  },
  GetFollowingList:
  {
    screen: GetFollowingList
  },
  EditUserAccount:
  {
    screen:EditUserAccount
  },
  SearchedUserProfile:
  {
    screen:SearchedUserProfile
  }
});
const AppContainer = createAppContainer(AppStackNav)

export default AppContainer;
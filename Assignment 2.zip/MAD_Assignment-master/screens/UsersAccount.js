import React, { Component } from "react";
import {StyleSheet,View,Alert,ActivityIndicator,TouchableOpacity,Text,Image, FlatList} from 'react-native';

//Class
class UsersAccount extends React.Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
      super(props);
      this.state = 
      {
         id: '',
         token: '',
         ListOfChits:[],
         isLoading: true,
         given_name: "",
         family_name:"",
         email:"",
         ProfilePic:"",
      }
   }

   //Set ID + Token And Wait Until This is done 
   async setIDTokenUserAccount()
  {
    await this.setState
    ({
      id:this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Users Account: " + this.state.id);
    console.log("Users Account: " + this.state.token); 
  }

  //Get Chits
  getChits()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/chits")
    .then((response) => response.json())
    .then((responseJson) => 
    {
      this.setState
      ({
        isLoading: false,
        ListOfChits: responseJson,
      });
    })
    .catch((error) =>
    {
      Alert.alert("Could Not Load Chits!"),
      console.log(error);
    });
  }

  //Set ID + Token, Get User by ID, Get Chits, Get Profile Pic on load
  componentDidMount()
  {
    this.setIDTokenUserAccount();
    this.GetUserBYID();
    this.getChits();
    this.getProfilePic();
    this._subscribe = this.props.navigation.addListener('didFocus', () => { this.getChits()} ); //REFRESH CHITS ONCE POSTED
  }

  //Get Profile Pic
  getProfilePic()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/photo")
    .then((response) => 
      {
        this.setState({ProfilePic:response.url})
        console.log("PROFILE PIC ------------" +  this.state.ProfilePic)
      })
  }

  //Get User By ID
  GetUserBYID()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID"))
    .then((response) => response.json())
    .then((GetUserBYIDJSON) => 
    {
      this.setState
      ({
        given_name: GetUserBYIDJSON.given_name,
        family_name: GetUserBYIDJSON.family_name,
        email: GetUserBYIDJSON.email,
      })

      console.log("Name:" + GetUserBYIDJSON.given_name),
      console.log("Family Name:" + GetUserBYIDJSON.family_name),
      console.log("Email:" + GetUserBYIDJSON.email);
    })
  }

  //logout
   logout()
   {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/logout",
      {
        method: 'POST',
        headers: 
         {
            'X-Authorization' : this.state.token,
         }
      })
      .then((response) => 
      {
        this.props.navigation.navigate('HomeScreen');
      })
      .catch((error) => 
      {
        Alert.alert("Cannot Log Out");
      })
    }

  render() 
  {
    if(this.state.isLoading)
    {
      return(
        <View>
          <ActivityIndicator/>
        </View>
      )
    }

    {/* //Get Params */}
    const id = this.props.navigation.getParam("id", "NO-ID")   
    const token = this.props.navigation.getParam("token", "NO-Token") 
    console.log("User Account RENDER:" + id);
    console.log("User Account RENDER:" + token); 
    return (

      <View>

          {/* //See Chit List */}
          <FlatList
          contentContainerStyle={{flexGrow: 1}}
          data={this.state.ListOfChits}
          renderItem={({item}) => <Text style = {styles.item}>{item.chit_content}</Text>}
          keyExtractor={(id, index) => id}
          />

            {/* //Log Out Button */}
            <TouchableOpacity
              style = {styles.ButtonLogOut}
              onPress={() =>  { this.logout() }}
            >

            <Text style = {styles.ButtonLogOutText}> Logout</Text> 
            </TouchableOpacity>

            {/* //Edit Profile Button */}
            <TouchableOpacity
              style = {styles.ButtonEditProfile}
              onPress={() => this.props.navigation.navigate('EditUserAccount',
            {
              token:token,
              id:id,
            })} 
            >
            <Text style = {styles.ButtonEditProfileText}>Edit Profile</Text> 
            </TouchableOpacity>

             {/* //Profile Pic */}
             <Image source={{uri:this.state.ProfilePic}} 
              style=
              {
                {
                  top: 50,
                  left:25,
                  width:70,
                  height:70,
                  position: "absolute",
                  borderColor:"#000000",
                  borderWidth:1,
                }
              } />

            {/* //User Name */}
            <Text style = {styles.YourUserName}> {this.state.given_name + " " + this.state.family_name} </Text>

            {/* //Followers Button */}
            <TouchableOpacity
            style = {styles.ButtonFollowers}
            onPress={() => this.props.navigation.navigate('GetFollowersList',
            {
              token:token,
              id:id,
            })}
            >

            <Text style = {styles.ButtonFollowersText}> Followers</Text> 
            </TouchableOpacity>

            {/* //Following Button */}
            <TouchableOpacity
              style = {styles.ButtonFollowing} 
              onPress={() => this.props.navigation.navigate('GetFollowingList',
              {
                token:token,
                id:id,
              })}
            >
            <Text style = {styles.ButtonFollowingText}>Following</Text> 
            </TouchableOpacity>

    </View>
     
    );
  }
}
export default UsersAccount;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1, 
  },
  ButtonLogOut: 
  {  
    top: 10,
    left:10,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonLogOutText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  ButtonEditProfile: 
  {  
    top: 10,
    left:280,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonEditProfileText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  image: 
  {
    top: 50,
    left:25,
    width:70,
    height:70,
    position: "absolute",
  },
  YourUserName:
  {
    top:-350,
    left:0,
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  ButtonFollowers: 
  {  
    top: 125,
    left:280,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonFollowersText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  ButtonFollowing: 
  {  
    top: 125,
    left:10,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonFollowingText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center',
  },
  item: 
  {
   height:"auto",
   backgroundColor: '#009688',
   top:160,
   marginVertical:5,
   padding:5,
   fontSize: 18,
   fontFamily: "arial-regular"
  }
  });
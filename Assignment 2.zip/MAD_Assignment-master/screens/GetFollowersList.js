import React, { Component } from "react";
import {View,StyleSheet,FlatList,Text} from 'react-native';

//Class
class GetFollowersList extends React.Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
      super(props);
      this.state = 
      {
         id: "",
         user_id:"",
         given_name: "",
         family_name: "",
         email: "",
         token: "",
         FollowersList:[],
      }
   }

  //Set ID + Token And Wait Until This is done 
   async setIDTokenGetFollowersList()
  {
    await this.setState
    ({
      id:this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Get Followers List: " + this.state.id);
    console.log("Get Followers List: " + this.state.token); 
  }
  
  //On Load Set ID + Token + Get Followers
  componentDidMount()
  {
    this.setIDTokenGetFollowersList();
    this.getFollowers();
  }

  //Get Followers
  getFollowers()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/followers")
    .then((response) => response.json())
    .then((GetFollowersBYIDJSON) => 
    {
      console.log("FOLLOWERS JSON:" + GetFollowersBYIDJSON)

      this.setState
      ({
        FollowersList:GetFollowersBYIDJSON
      })
    })
  }

  render() 
  {
    return (

      <View>
            
            <Text style = {styles.FollowersText}> FOLLOWERS </Text>

            {/* //See Following List */}
            <FlatList
            contentContainerStyle={{flexGrow: 1}}
            data={this.state.FollowersList}
            renderItem={({item}) => <Text style = {styles.item}>{item.given_name + " " + item.family_name}</Text>}
            keyExtractor={(id, index) => id}
            />

        </View>
     
    );
  }
}
export default GetFollowersList;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1, 
  },
  FollowersText:
  {
    top:0,
    left:0,
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  item: 
  {
    backgroundColor: '#009688',
    top:10,
    marginVertical:5,
    padding:5,
    fontSize: 18,
    fontFamily: "arial-regular",
  }
})
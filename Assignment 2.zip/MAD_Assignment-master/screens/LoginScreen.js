import React, { Component } from 'react';
import {StyleSheet, View, Image, Text,TextInput,TouchableOpacity,Alert } from 'react-native';

//Class
class LoginScreen extends React.Component 
{
   //Dont show header
  static navigationOptions = 
  {
    headerShown: false
  }
  //Constructor (Props Used as Variables)
  constructor(props)
  {
     super(props);
     this.state = 
     {
        email:"",
        password:"",
        id: null,
        token: null
     };
  }
  
  //Login
  login()
  {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/login",
      {
         method: 'POST',
         headers: 
         {
            'Content-Type': 'application/json',
         },
         body: JSON.stringify
         ({
            email: this.state.email,
            password: this.state.password
         })
      })
         .then((response) => response.json())
         .then((LoginResponse) => 
         {
            LoginResponse.id,
            LoginResponse.token,

            console.log("User ID:" + LoginResponse.id),
            console.log("User Token:" + LoginResponse.token),
            
            this.props.navigation.navigate('LoginAuthenticating',
            {
               //Pass Paramaters through screens
               token:LoginResponse.token,
               id:LoginResponse.id,
            })
         })
         .catch((error) => 
         {
            Alert.alert("You have entered an invalid username or password");
         })
   }

  render()
  {
    return (
        <View style={styles.container}>

           {/* Chittr Logo */}
             <Image
            source={require('./assets/images/Chitter-Logo.png')}
            resizeMode="contain"
            style={styles.image}>
         </Image> 
        
         {/* //Email */}
         <Text style={styles.EmailText}>Email:</Text>
         <TextInput
            style = {styles.EmailInput}
            placeholder =" Testing@test.co.uk" 
            onChangeText={(text) => this.setState({email:text})} 
         />

         {/* //Password */}
         <Text style={styles.PasswordText}>Password:</Text>
         <TextInput
            style = {styles.PassowrdInput}
            placeholder ="Password!"
            secureTextEntry={true} 
            onChangeText={(text) => this.setState({password:text})} 
         />

          {/* //Login Button */}
          <TouchableOpacity
            style = {styles.ButtonLogin}
            onPress={() => 
            {
              this.login();
            }
            }
          >
          {/* //Login Button Text */}   
          <Text style = {styles.ButtonLoginText}>Login</Text> 
          </TouchableOpacity>
        </View>
      )
  }
}
export default LoginScreen;

{/* //Style Sheet */}
const styles = StyleSheet.create({
container: 
{
  flex: 1,
  alignItems:"center",
  justifyContent:"center"  
},
image: 
{
  top: 30,
  justifyContent:"center",
  width: 200,
  height: 200,
  position: "absolute"
},

EmailText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:25,
   marginLeft:-245
},

EmailInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:50,
   width:250
},

PasswordText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:25,
   marginLeft:-210
},

PassowrdInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:120,
   width:250
},

ButtonLogin: 
{  
  top: 610,
  width: 200,
  borderRadius: 20,
  padding: 10,
  borderRadius: 20,
  position: "absolute",
  backgroundColor: '#ADD8E6'
}, 
ButtonLoginText:
{
  fontSize:18,
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center'
}
});
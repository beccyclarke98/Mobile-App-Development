import React, { Component } from 'react';
import {View, Text, ProgressBarAndroid, StyleSheet} from 'react-native';

//Class
class LoginAuthenticating extends React.Component 
{
  //Dont show header
  static navigationOptions = 
  {
    headerShown: false
  }

  render()
  {
    //Get Params
    const { navigation } = this.props;  
    const id = navigation.getParam('id', 'NO-ID');  
    const token = navigation.getParam('token', 'NO-Token');  

    console.log("Login Authen:" + id);
    console.log("Login Authen:" + token);
    

      this.props.navigation.navigate('MainSeeChits',
    {
      //Pass Paramaters through screens
      token: token,
      id: id,
    });
    

    return (
      
        <View style={styles.container}>
            <Text> Login Authenticating </Text>
            <ProgressBarAndroid progress = {0.5} width = {200} />
        </View>
      )
  }
}
export default LoginAuthenticating;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1,
    alignItems:"center",
    justifyContent:"center"  
  }
})
import React, { Component } from "react";
import {View,Text,FlatList,StyleSheet} from 'react-native';

//Class
class GetFollowingList extends React.Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
      super(props);
      this.state = 
      {
         id: "",
         user_id:"",
         given_name: "",
         family_name: "",
         email: "",
         token: "",
         FollowingList:[],
      }
   }

   //Set ID + Token And Wait Until This is done 
   async setIDTokenGetFollowersList()
  {
    await this.setState
    ({
      id:this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Get Following List: " + this.state.id);
    console.log("Get Following List: " + this.state.token); 
  }
  
  //On Load set ID+ Token + Get following
  componentDidMount()
  {
    this.setIDTokenGetFollowersList();
    this.GetFollowing();
  }

  //Get Following
  GetFollowing()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/following")
    
    .then((response) => response.json())
    .then((GetFollowingBYIDJSON) => 
    {
      console.log("FOLLOWING JSON:" + GetFollowingBYIDJSON)

      this.setState
      ({
          FollowingList:GetFollowingBYIDJSON
      })

    })
  }

  render() 
  {
    return (

      <View style={styles.container}>

      <Text style = {styles.FollowingText}> FOLLOWING </Text>

              {/* //See Following List */}
              <FlatList
              contentContainerStyle={{flexGrow: 1}}
              data={this.state.FollowingList}
              renderItem={({item}) => <Text style = {styles.item}>{item.given_name + " " + item.family_name}</Text>}
              keyExtractor={(id, index) => id}
              />
    </View>
     
    );
  }
}
export default GetFollowingList;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1, 
  },
  FollowingText:
  {
    top:0,
    left:0,
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  item: 
  {
    backgroundColor: '#009688',
    top:10,
    marginVertical:5,
    padding:5,
    fontSize: 18,
    fontFamily: "arial-regular",
  }
})
import React, { Component } from 'react';
import {StyleSheet,View,Text,Alert,TextInput,FlatList,TouchableHighlight,TouchableOpacity} from 'react-native';

//Class
class SearchUserResultList extends Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }
   
   //Constructor (Props Used as Variables)
   constructor(props)
   {
    super(props);
    this.state =
    {
      SearchBarInputedTextByUser: "",
      ResultList:[],
      SelectedID:0,
      //LOGGED IN USER
      id:0,
      token:null,
      
    }
  }

   //Set ID + Token And Wait Until This is done 
  async setIDToken()
  {
    await this.setState
    ({
      id: this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Search User Result ID: " + this.state.id);
    console.log("Search User Result Token: " + this.state.token); 
  }
  
  //On Load set ID + Token
  componentDidMount()
  {
    this.setIDToken();
  }

  //Search User
  SearchUser()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/search_user" + "?q=" + this.state.SearchBarInputedTextByUser)
      .then((response) =>  response.json())
      .then((searchUserJSON) =>
      {
        console.log(searchUserJSON)
        console.log(searchUserJSON[0].given_name)

          this.setState
          ({
            ResultList:searchUserJSON,
          })
      })
      .catch((error) =>
      {
        Alert.alert("Please Enter A Valid User Name!");
        console.log(error);
      });
  }

  //Get The ID Of the user clicked on
  itemClicked(item)
  {
    console.log("CLICKED USER ID NUMBER:" + item)

    this.props.navigation.navigate('SearchedUserProfile', 
    { 
      //Pass Paramaters through screens
      token: this.state.token,
      id: this.state.id,
      SelectedID: item
    })
  }

  render() 
  { 
    return (

      <View style={styles.container}>
      {/* //See User List */}
      
      <FlatList
      contentContainerStyle={{flexGrow: 1}}
      data={this.state.ResultList} 
      renderItem = {({item}) => <Text style = {styles.item} onPress =  {this.itemClicked.bind(this,item.user_id)} > {item.given_name + " " + item.family_name}  </Text>}
      keyExtractor={(id, index) => id} 
      />
      
    {/* //Search User Input Box*/}
      <TextInput 
        style = {styles.searchTextBox}
        placeholder = "Search User!"
        onChangeText={(String) => this.setState({SearchBarInputedTextByUser:String})} 
      />

      {/* //Search User Input Box*/}
      <TouchableOpacity
        style={styles.SearchButton} 
        onPress={() => this.SearchUser() }
      >
      <Text style={styles.searchButtonText}> Search</Text>
      </TouchableOpacity>

      </View>
    );
  }
}
export default SearchUserResultList;

{/* //Style Sheet */}
const styles = StyleSheet.create({
    container: 
    {
       flex: 1,
    },
    Text:
    {
      fontSize:18,
      fontFamily:"arial-regular",
      color:"#000000",
    },
    searchTextBox: 
    {
       flex:1,
       height:40,
       width:300,
       left:5,
       top:10,
       borderWidth: 1,
       position:"absolute",
       borderColor: '#009688',
    },
    item: 
    {
      padding:10,
      marginTop:"15%",
      backgroundColor: '#009688',
    },
    SearchButton: 
    { 
      flex:1, 
      top: 18,
      right: 10,
      height: 30,
      width: 70,
      borderRadius: 20,
      padding: 5,
      borderRadius: 10,
      position: "absolute",
      backgroundColor: '#ADD8E6'
    },
    searchButtonText:
    {
      top: -25,
      color: "#000000",
      fontSize: 18,
      fontFamily: "arial-regular",
    }
});
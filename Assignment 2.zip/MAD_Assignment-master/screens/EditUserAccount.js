import React, { Component } from "react";
import {View,StyleSheet,Text,Image,TextInput,PixelRatio,Alert,TouchableOpacity} from 'react-native';
import ImagePicker from 'react-native-image-picker';

//Class
class EditUserAccount extends React.Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
      super(props);
      this.state = 
      {
        id:"",
        token:"",
        given_name: "",
        family_name:"",
        email:"",
        password:"",
        ImageSource: null,
        ImageBASE64: null,
      }
   }

  //Set ID + Token And Wait Until This is done 
   async setIDTokenEditUserAccount()
  {
    await this.setState
    ({
      id:this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Edit User Account: " + this.state.id);
    console.log("Edit User Account: " + this.state.token); 
  }
  
  //On Load Set ID + Token
  componentDidMount()
  {
    this.setIDTokenEditUserAccount();
  }

  //Update User
  UpdateUser()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","NO-ID"),
      {
         method: 'PATCH',
         headers:
          {
            'Content-Type': 'application/json',
            'X-Authorization' : this.state.token,
          },
         body: JSON.stringify
         ({
            given_name: this.state.given_name,
            family_name: this.state.family_name,
            email: this.state.email,
            password: this.state.password
         })
      })
         .then((response) =>
         {
           Alert.alert("Account Updated!");
           this.props.navigation.navigate("UsersAccount")
         })
         .catch((error) => {
         console.error(error);
      })
  }

  //Post User Profile Photo
  PostUserProfilePhoto()
  {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/user/photo",
      {
         method: 'POST',
         headers: 
         {
            'Content-Type': 'image/jpeg',
            'X-Authorization' : this.state.token
         },
         body:this.state.ImageBASE64,
      })
         .then((response) => response.json())
         .then((responseJson) => 
         {
            this.props.navigation.goBack(); //GO BACK TO UserAccount
            Alert.alert("Posted Successfully!")
            console.log("POSTED DATA: " + this.state.ImageBASE64)
         })
         .catch((error) => 
         {      
            console.log("IMAGE SOURCE ---------- : " + this.state.ImageBASE64)
            Alert.alert("Cannot Post User Photo");
         })
   }

   //Choose Image (Camera/From Library)
   ChooseImage() 
    {
      const options = 
      {
        quality: 1.0,
        maxWidth: 500,
        maxHeight: 500,
        storageOptions: 
        {
          skipBackup: true
        }
      };

      ImagePicker.showImagePicker(options, (response) => 
    {
          console.log('Response = ', response); 
          this.setState({ImageBASE64:response.data})
          console.log("IN IMAGE PICKER SETTING: " + this.state.ImageBASE64)

          if (response.didCancel)
          {
            console.log('Cancel'); // Cancel Button On Take Photo/Choose Photo Box
          }
          else if (response.error) 
          {
            console.log('Error: ', response.error);
          }
          else if (response.customButton)
          {
            console.log('User tapped custom button: ', response.customButton);
          }
          else 
          {
            let source = { uri: response.uri };
            this.setState({ImageSource: source});
          }
        });
      }

  render() 
  {
    return (

      <View style={styles.container}>

        {/* //Cancel Button */}
        <TouchableOpacity
        style = {styles.ButtonCancel}
        onPress = {() => this.props.navigation.navigate('UsersAccount')}
        >

      <Text style = {styles.ButtonCancelText}> Cancel</Text> 
      </TouchableOpacity>

      {/* //Save Button */}
          <TouchableOpacity
          style = {styles.ButtonSave}
          onPress = {() => this.UpdateUser()}
         >
        <Text style = {styles.ButtonSaveText}>Save</Text> 
      </TouchableOpacity>  
        
       {/* Profile Pic */} 
      <Image source={{uri: "http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/photo"}} 
         style=
         {
           {
            top:70,
            left:20,
            justifyContent:"center",
            width: 150,
            height: 150,
            position: "absolute",
            borderColor:"#000000",
            borderWidth:1,
           }
        } 
      />

      {/* //First Name */}
      <Text style={styles.firstNameText}>First Name:</Text>
      <TextInput
        style = {styles.firstNameInput}
        placeholder =" John"
        onChangeText={(text) => this.setState({given_name : text})}  
      />

      {/* //Last Name */}
      <Text style={styles.LastNameText}>Last Name:</Text>
      <TextInput
        style = {styles.LastNameInput}
        placeholder =" Doe" 
        onChangeText={(text) => this.setState({family_name:text})} 
      />

      {/* //Email */}
      <Text style={styles.EmailText}>Email:</Text>
      <TextInput
        style = {styles.EmailInput}
        placeholder =" Testing@test.co.uk"
        onChangeText={(text) => this.setState({email:text})} 
      />

      {/* //Password */}
      <Text style={styles.PasswordText}>Password:</Text>
      <TextInput
        style = {styles.PassowrdInput}
        placeholder ="TestPassword!"
        secureTextEntry={true} 
        onChangeText={(text) => this.setState({password:text})}
      />

      {/* //Post Chit ID Photo */}
      <TouchableOpacity onPress={this.ChooseImage.bind(this)}>
 
      <View style={styles.CameraScreen}>
       { 
        this.state.ImageSource === null ? <Text>Upload User Profile Pic</Text> :
        <Image style ={styles.ImageTaken} source={this.state.ImageSource} />
            
      }
      </View>
          
      </TouchableOpacity>

      {/* //Post Photo Button */}
      <TouchableOpacity
        style = {styles.ButtonPostUserPhoto}
          onPress={() => this.PostUserProfilePhoto()} 
      >
            <Text style = {styles.ButtonPostUserPhotoText}>Post User Photo</Text> 
            </TouchableOpacity>

    </View>
     
    );
  }
}
export default EditUserAccount;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1,
    alignItems:"center",
    justifyContent:"center"  
  },
  ButtonCancel: 
  {  
    top: 10,
    left:10,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonCancelText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  ButtonSave: 
  {  
    top: 10,
    left:280,
    width: 100,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonSaveText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  firstNameText: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:175,
     marginLeft:-200,
     
  },
  firstNameInput: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:-35,
     marginLeft:100,
     width:200
  },
  
  LastNameText: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:25,
     marginLeft:-200
  },
  
  LastNameInput: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:-35,
     marginLeft:100,
     width:200
  },
  
  EmailText: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:25,
     marginLeft:-245
  },
  
  EmailInput: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:-35,
     marginLeft:50,
     width:250
  },
  
  PasswordText: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:25,
     marginLeft:-210
  },
  PassowrdInput: 
  {
     color: "#121212",
     fontSize: 18,
     fontFamily: "arial-regular",
     marginTop:-35,
     marginLeft:75,
     width:200
  },
  ButtonPostUserPhoto: 
  {  
    top:600,
    left:100,
    width: 200,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonPostUserPhotoText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  CameraScreen:
  {
    top:-410,
    left:70,
    borderRadius: 10,
    width: 150,
    height: 150,
    borderColor: '#ADD8E6',
    borderWidth: 1 / PixelRatio.get(),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ADD8E6',
  }
});
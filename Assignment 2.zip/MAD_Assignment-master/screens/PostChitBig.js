import React, { Component } from "react";
import {StyleSheet, View, Text, Image,TextInput,PixelRatio, TouchableOpacity, Alert} from 'react-native';
import ImagePicker from 'react-native-image-picker';

//Class
class PostChitBig extends React.Component 
{
  //Dont show header
  static navigationOptions = 
  {
    headerShown: false
  }

  //Constructor (Props Used as Variables)
  constructor(props)
  {
     super(props);
     this.state = 
     {
        chit_id: 0,
        timestamp: 0,
        chit_content: "",
        longitude: 0,
        latitude: 0,
        user_id: '',
        given_name: "",
        family_name: "",
        email: "",
        token:'',
        ImageSource: null,
        ImageBASE64:null,
     }
    }

  //Set ID + Token And Wait Until This is done 
  async setIDToken()
  {
    await this.setState
    ({
      user_id: this.props.navigation.getParam("id","N0-ID"),
      token:this.props.navigation.getParam("token", "NO-Token"),
    })
    console.log("Get User Information ID: " + this.state.user_id);
    console.log("Get User Information Token: " + this.state.token); 
  }
  
   //On Load Set ID + Token and Get User By ID
  componentDidMount()
  {
    this.setIDToken();
    this.GetUserBYID();
  }

  //Get User By Their ID
  GetUserBYID()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID"))
    .then((response) => response.json())
    .then((GetUserBYIDJSON) => 
    {
      this.setState
      ({
        given_name: GetUserBYIDJSON.given_name,
        family_name: GetUserBYIDJSON.family_name,
        email: GetUserBYIDJSON.email,
      })

      console.log("Name:" + GetUserBYIDJSON.given_name),
      console.log("Family Name:" + GetUserBYIDJSON.family_name),
      console.log("Email:" + GetUserBYIDJSON.email);
    })
  }

  //Post Chits
  postChits()
  {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/chits",
      {
         method: 'POST',
         headers: 
         {
            'Content-Type': 'application/json',
            'X-Authorization' : this.state.token,
         },
         body: JSON.stringify
         ({
            chit_id: this.state.chit_id,
            timestamp: Date.now(),
            chit_content: this.state.chitmessage,
            longitude: 0,
            latitude: 0,
            user_id: this.state.user_id,
            given_name: this.state.given_name,
            family_name: this.state.family_name,
            email: this.state.email
         })
      })
         .then((response) =>
         {
            this.props.navigation.goBack(); //GO BACK TO MAIN SEE CHITS
         })
         .catch((error) => 
         {
            Alert.alert("Cannot Post Chit");
            this.props.navigation.goBack(); 
         })
   }

   //Post Chit Photo
   PostChitPhoto()
  {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/chits/" + this.props.navigation.getParam("id","N0-ID") + "/photo",
      {
         method: 'POST',
         headers: 
         {
            'Content-Type': 'image/jpeg',
            'X-Authorization' : this.state.token
         },
         body:this.state.ImageBASE64,
      })
         .then((response) =>  
         {
            this.props.navigation.goBack(); //GO BACK TO MAIN SEE CHITS
            Alert.alert("Posted Successfully!")
            console.log("POSTED DATA: " + this.state.ImageBASE64)
         })
         .catch((error) => 
         {
            console.log("IMAGE SOURCE ---------- : " + this.state.ImageBASE64)
            Alert.alert("Cannot Post Chit Photo");
            Console.log("http://10.0.2.2:3333/api/v0.0.5/chits/" + this.props.navigation.getParam("id","N0-ID") + "/photo")
         })
   }

   //Choose Image (Camera/From Library)
   ChooseImage() 
    {
      const options = 
      {
        quality: 1.0,
        maxWidth: 500,
        maxHeight: 500,
        storageOptions: 
        {
          skipBackup: true
        }
      };

      ImagePicker.showImagePicker(options, (response) => 
    {
          console.log('Response = ', response);
          this.setState({ImageBASE64:response.data})
          console.log("IN IMAGE PICKER SETTING: " + this.state.ImageBASE64)

    
          if (response.didCancel)
          {
            console.log('Cancel'); // Cancel Button On Take Photo/Choose Photo Box
          }
          else if (response.error) 
          {
            console.log('Error: ', response.error);
          }
          else if (response.customButton)
          {
            console.log('User tapped custom button: ', response.customButton);
          }
          else 
          {
            let source = { uri: response.uri };
            this.setState({ImageSource: source});
            this.setState({ImageBASE64:response.data})
            console.log("IN IMAGE PICKER SETTING: " + this.state.ImageBASE64)
          }
        });
      }

    render() 
    {
      const { navigate } = this.props.navigation;
      return (  
        <View>
              {/* //Post Chit Button */}
              <TouchableOpacity
              style = {styles.ButtonPostChit}
              onPress={() => this.postChits()}
              >

            <Text style = {styles.ButtonPostChitText}>Post Chit</Text> 
            </TouchableOpacity>

            {/* //Cancel Chit Button */}
            <TouchableOpacity
              style = {styles.ButtonCancel}
              onPress={() => this.props.navigation.goBack()} //GO BACK TO MAIN SEE CHITS
            >
            <Text style = {styles.ButtonCancelText}>Cancel</Text> 
            </TouchableOpacity>

            {/* //Profile Pic */}
            <Image source={{uri: "http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/photo"}} 
             style=
            {
              {
                top:70,
                left:30,
                width: 75,
                height: 75,
                position: "absolute",
                borderColor:"#000000",
                borderWidth:1,
              }
            } />

           {/* //Post Chit Big Text Input */}
           <TextInput
            style = {styles.PostChitMessageText}
            placeholder ="Post Chit Message!"
            onChangeText={(text) => this.setState({chitmessage:text})} 
            maxLength = {141}
            />
          

          {/* //Post Chit ID Photo */}
          <TouchableOpacity onPress={this.ChooseImage.bind(this)}>
 
          <View style={styles.CameraScreen}>
          { 
            this.state.ImageSource === null ? <Text>Attach A Photo To The Chit!</Text> :
            <Image style ={styles.ImageTaken} source={this.state.ImageSource} />
            
          }
          </View>
          
          </TouchableOpacity>

          {/* //Post Photo Button */}
          <TouchableOpacity
              style = {styles.ButtonPostChitPhoto}
              onPress={() => this.PostChitPhoto()} 
            >
            <Text style = {styles.ButtonPostChitPhotoText}>Post Chit Photo</Text> 
            </TouchableOpacity>


        </View>
      );
    }
  }
export default PostChitBig;
{/* //Style Sheet */}
const styles = StyleSheet.create({
container: 
{
  flex: 1,
  justifyContent:"center",  
  alignItems:"center",
},
ButtonPostChitPhoto: 
{  
  top:500,
  left:100,
  width: 200,
  borderRadius: 20,
  padding: 5,
  borderRadius: 20,
  position: "absolute",
  backgroundColor: '#ADD8E6'
}, 
ButtonPostChitPhotoText:
{
  fontSize:18,
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center'
},
CameraScreen:
{
  top:75,
  left:125,
  borderRadius: 1,
  width: 150,
  height: 150,
  borderColor: '#ADD8E6',
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center',
  borderWidth: 100 / PixelRatio.get(),
  backgroundColor: '#ADD8E6',
},
ImageTaken:
{
  top:600,
  left:70,
  borderRadius: 10,
  width: 350,
  height: 350,
  borderColor: '#ADD8E6',
  borderWidth: 1 / PixelRatio.get(),
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#ADD8E6',
},
PostChitMessageText: 
{
   top:10,
   left:110,
   height:200,
   width:"50%",
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular"
},
ButtonPostChit: 
{  
  top: 10,
  left:280,
  width: 100,
  borderRadius: 20,
  padding: 5,
  borderRadius: 20,
  position: "absolute",
  backgroundColor: '#ADD8E6'
}, 
ButtonPostChitText:
{
  fontSize:18,
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center'
},
ButtonCancel: 
{  
  top: 10,
  left:10,
  width: 100,
  borderRadius: 20,
  padding: 5,
  borderRadius: 20,
  position: "absolute",
  backgroundColor: '#ADD8E6'
}, 
ButtonCancelText:
{
  fontSize:18,
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center'
}
});
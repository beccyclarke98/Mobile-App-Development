import React, { Component } from 'react';
import {StyleSheet, View, Image, Text,TextInput, TouchableOpacity,Alert, KeyboardAvoidingView } from 'react-native';

//Class
class CreateAccount extends React.Component 
{
   //Dont show header
  static navigationOptions = 
  {
    headerShown: false
  }

  //Constructor (Props Used as Variables)
  constructor(props)
  {
     super(props);
     this.state = 
     {
        given_name: "",
        family_name:"",
        email:"",
        password:""
     };
  }

  //Creating Account
  CreateAccount()
  {
      return fetch("http://10.0.2.2:3333/api/v0.0.5/user",
      {
         method: 'POST',
         headers: {
            'Content-Type': 'application/json',
          },
         body: JSON.stringify
         ({
            given_name: this.state.given_name,
            family_name: this.state.family_name,
            email: this.state.email,
            password: this.state.password
         })
      })
         .then((response) => {Alert.alert("Account Created!");
         })
         .catch((error) => {
         console.error(error);
      })
   }

  render()
  {
    return (
        <View style={styles.container}>

           {/* Chittr Logo */}
             <Image
            source={require('./assets/images/Chitter-Logo.png')}
            resizeMode="contain"
            style={styles.image}>
         </Image> 
        
        {/* //First Name */}
         <Text style={styles.firstNameText}>First Name:</Text>
         <TextInput
            style = {styles.firstNameInput}
            placeholder =" John"
            onChangeText={(text) => this.setState({given_name : text})}
            
         />
         {/* //Last Name */}
         <Text style={styles.LastNameText}>Last Name:</Text>
         <TextInput
            style = {styles.LastNameInput}
            placeholder =" Doe" 
            onChangeText={(text) => this.setState({family_name:text})}
           
         />
         {/* //Email */}
         <Text style={styles.EmailText}>Email:</Text>
         <TextInput
            style = {styles.EmailInput}
            placeholder =" Testing@test.co.uk"
            onChangeText={(text) => this.setState({email:text})} 
         />

         {/* //Password */}
         <Text style={styles.PasswordText}>Password:</Text>
         <TextInput
            style = {styles.PassowrdInput}
            placeholder ="TestPassword!"
            secureTextEntry={true} 
            onChangeText={(text) => this.setState({password:text})}
         />

          {/* //Create Account Button */}
          <TouchableOpacity
            style = {styles.ButtonCreateAccount}
            onPress={() => {
              this.CreateAccount();
              this.props.navigation.navigate('LoginScreen')}
            }
          >
         {/* //Create Account Button Text */}
          <Text style = {styles.ButtonCreateAccountText}>Create Account</Text> 
          </TouchableOpacity>
        </View>
      )
  }
}
export default CreateAccount;

{/* //Style Sheet */}
const styles = StyleSheet.create({
container: 
{
  flex: 1,
  alignItems:"center",
  justifyContent:"center"  
},
image: 
{
  top: 30,
  justifyContent:"center",
  width: 200,
  height: 200,
  position: "absolute"
},
firstNameText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:75,
   marginLeft:-200,
   
},

firstNameInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:100,
   width:200
},

LastNameText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:25,
   marginLeft:-200
},

LastNameInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:100,
   width:200
},

EmailText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:25,
   marginLeft:-245
},

EmailInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:50,
   width:250
},

PasswordText: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:25,
   marginLeft:-210
},

PassowrdInput: 
{
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular",
   marginTop:-35,
   marginLeft:75,
   width:200
},

ButtonCreateAccount: 
{  
  top: 610,
  width: 200,
  borderRadius: 20,
  padding: 10,
  borderRadius: 20,
  position: "absolute",
  backgroundColor: '#ADD8E6'
}, 
ButtonCreateAccountText:
{
  fontSize:18,
  textAlign: "center",
  justifyContent: 'center', 
  alignItems: 'center'
}
});
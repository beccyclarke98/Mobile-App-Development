import React, { Component } from "react";
import { StyleSheet, View, Image, Text, TouchableOpacity} from "react-native";

class HomeScreen extends React.Component 
{
  static navigationOptions = 
  {
    headerShown: false
  }

  render()
  {
    return (
        <View style={styles.container}>
             <Image
            source={require('./assets/images/Chitter-Logo.png')}
            resizeMode="contain"
            style={styles.image}
          ></Image> 

          {/* //Create Account Button */}
          <TouchableOpacity
            style = {styles.ButtonCreateAccount}
            onPress={() => this.props.navigation.navigate('CreateAccount')}
          >
          <Text style = {styles.ButtonCreateAccountText}>Create Account</Text> 
          </TouchableOpacity>

          {/* //Login Button */}
          <TouchableOpacity
            style = {styles.ButtonLogin}
            onPress={() => this.props.navigation.navigate('LoginScreen')}
          >
          <Text style = {styles.ButtonLoginText}>Login</Text> 
          </TouchableOpacity>

          <Text style={styles.AlreadyHaveAnAccountBottomText}>Already Have An Account:</Text>
        </View>
      )
  }
}
export default HomeScreen;

const styles = StyleSheet.create({
  container: 
  {
    flex: 1,
    alignItems:"center",
    justifyContent:"center",

  },
  image: 
  {
    top: 80,
    width: 317,
    height: 314,
    position: "absolute"
  },
  ButtonCreateAccount: 
  {
    top: 410,
    width: 200,
    borderRadius: 20,
    padding: 10,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonCreateAccountText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },

  AlreadyHaveAnAccountBottomText:
  {
    top: 670,
    left: 17,
    color: "black",
    position: "absolute",
    fontSize: 18,
    fontFamily: "arial-regular"
  },
  ButtonLogin: 
  {
    top: 661,
    left: 233,
    width: 150,
    padding: 10,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonLoginText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  } 
});

import React, { Component } from 'react';
import {StyleSheet,View,Text,Alert,TouchableOpacity,Image} from 'react-native';

//Class
class SearchedUserProfile extends Component
 {
    //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
     super(props)
     this.state =
     {
        FollowingText: 'Follow',
        id:"",
        token:"",
        SelectedID:"",
        given_name: "",
        family_name: "",
        email: "",
     }
   }

   //Set ID + Token And Wait Until This is done 
   async setIDToken()
   {
     await this.setState
     ({
       id: this.props.navigation.getParam("id","N0-ID"),
       token:this.props.navigation.getParam("token", "NO-Token"),
       SelectedID:this.props.navigation.getParam("SelectedID", "NO-ID"),
     })
     console.log("Searched User Profile ID: " + this.state.id);
     console.log("Searched User Profile Token: " + this.state.token); 
     console.log("Searched User Profile SelectedID: " + this.state.SelectedID); 
   }
   
    //On Load set ID + Token and get user by ID
   componentDidMount()
   {
     this.setIDToken();
     this.GetUserBYID();
   }

   //Get User By ID
   GetUserBYID()
   {
     return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("SelectedID","N0-ID"))
     .then((response) => response.json())
     .then((GetUserBYIDJSON) => 
     {
       this.setState
       ({
         given_name: GetUserBYIDJSON.given_name,
         family_name: GetUserBYIDJSON.family_name,
         email: GetUserBYIDJSON.email,
       })
 
       console.log("Name:" + GetUserBYIDJSON.given_name),
       console.log("Family Name:" + GetUserBYIDJSON.family_name),
       console.log("Email:" + GetUserBYIDJSON.email);
     })
   }

   //Follow
   Follow()
   {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("SelectedID","N0-ID") + "/follow",
    {
      method: 'POST',
      headers: 
      {
        'X-Authorization' : this.state.token,
      },
    })
    .then((response) =>
    {
      Alert.alert("Followed User");
      this.props.navigation.navigate("MainSeeChits")

    })
    .catch((error) => 
    {
      Alert.alert("Cannot Follow User");
   })
  }

  //Unfollow
  Unfollow()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("SelectedID","N0-ID") + "/follow",
    {
      method: 'DELETE',
      headers: 
      {
        'X-Authorization' : this.state.token,
      },
    })
    .then((response) => 
    {
      Alert.alert("Unfollowed User");
      this.props.navigation.navigate("MainSeeChits")
    })
    .catch((error) => 
    {
      Alert.alert("Cannot Unfollow User");
   })
  }

  render() 
  {
    return (
      <View>

            {/* //Follow/Unfollow Profile Button */}
            <TouchableOpacity
              style = {styles.ButtonFollowProfile}
              onPress ={() =>
              {
                  this.Follow();
              }
              }
              >
            <Text style = {styles.ButtonFollow_UnfollowProfileText}>{this.state.FollowingText}</Text> 
            
            </TouchableOpacity>

            <TouchableOpacity
            style = {styles.ButtonUnfollowProfile}
            onPress ={() =>
            {
                this.Unfollow();
            }
              }
              >
            <Text style = {styles.ButtonFollow_UnfollowProfileText}> Unfollow </Text>
            </TouchableOpacity>

             {/* //Profile Pic */}
             <Image source={{uri: "http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("SelectedID","N0-ID") + "/photo"}} 
             style=
            {
              {
                top:5,
                left:3,
                width: 75,
                height: 75,
                position:"absolute",
                borderColor:"#000000",
                borderWidth:1,
              }
            } 
            />

            {/* //User Name */}
            <Text style = {styles.YourUserName}> {this.state.given_name + " " + this.state.family_name}</Text>

    </View>
    )
  }
}
export default SearchedUserProfile;

{/* //Style Sheet */}
const styles = StyleSheet.create({
  container: 
  {
    flex: 1, 
  },
  ButtonFollowProfile: 
  {  
    top:90,
    left:10,
    width:175,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonUnfollowProfile: 
  {  
    top:90,
    left:190,
    width:175,
    borderRadius: 20,
    padding: 5,
    borderRadius: 20,
    position: "absolute",
    backgroundColor: '#ADD8E6'
  }, 
  ButtonFollow_UnfollowProfileText:
  {
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  },
  image: 
  {
    top:30,
    left:30,
    width:70,
    height:70,
    position: "absolute",
  },
  YourUserName:
  {
    top:30,
    left:10,
    fontSize:18,
    textAlign: "center",
    justifyContent: 'center', 
    alignItems: 'center'
  }
});
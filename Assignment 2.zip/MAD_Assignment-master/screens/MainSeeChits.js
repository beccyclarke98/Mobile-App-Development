import React, { Component } from "react";
import {StyleSheet,View,FlatList,ActivityIndicator,TouchableOpacity,Text, Image,Alert, TextInput} from 'react-native';
import { ListItem } from 'react-native-elements'

//Class
class MainSeeChits extends React.Component
 {
   //Dont show header
   static navigationOptions = 
   {
     headerShown: false
   }

   //Constructor (Props Used as Variables)
   constructor(props)
   {
      super(props);
      this.state =
      {
        isLoading: true,
        ListOfChits: [],
        ChitsPhoto:"",
      }
    }
  
  /* When Screens Load, Get Chits, When it has a new focus get chits again (On Refresh) */
  componentDidMount()
  {
    this._subscribe = this.props.navigation.addListener('didFocus', () => { this.getChits()}); 
    this.getChits();
  }

  //Get Chits
  getChits()
  {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/chits")
    .then((response) => response.json())
    .then((responseJson) => 
    {
      this.setState
      ({
        isLoading: false,
        ListOfChits: responseJson,
      });
    })
    .catch((error) =>
    {
      Alert.alert("Could Not Load Chits!"),
      console.log(error);
    });
  }

  render() 
  {
    
    if(this.state.isLoading)
    {
      return(
        <View>
          <ActivityIndicator/>
        </View>
      )
    }
    
    //Get Params
    const id = this.props.navigation.getParam("id", "NO-ID")    
    const token = this.props.navigation.getParam("token", "NO-Token") 
    console.log("Main See Chits:" + id);
    console.log("Main See Chits:" + token); 
     
    return (
      
      <View style={styles.container}>
      
        {/* Chit List  */}
        <FlatList
          contentContainerStyle={{flexGrow: 1}}
          data={this.state.ListOfChits} //Get Chit Data
          renderItem={({item}) =>
          (
            <ListItem
            style = {styles.item}
            roundAvatar
            title = {item.chit_content}
            //Get Chits Photo To The Right Of The Chits
            rightAvatar = {{uri: "http://10.0.2.2:3333/api/v0.0.5/chits/" + item.user_id + "/photo"}}
            containerStyle={{backgroundColor:'#009688'}} 
            />
          )}
          keyExtractor={(id, index) => id}
          initialNumToRender={this.state.ListOfChits.length}
        />

        {/* Search Box  */}
         <TouchableOpacity
          style={styles.searchTextBox}
          onPress={() =>{this.props.navigation.navigate('SearchUserResultList',
          {
            //Pass Paramaters through screens
            token:token,
            id,id,
          })
          }}>
         <Text style={styles.searchText}>Search Here!</Text>
         </TouchableOpacity>

        <TouchableOpacity 
          style ={styles.image}
          onPress={() => 
          {
            this.props.navigation.navigate('UsersAccount',
            {
              //Pass Paramaters through screens
              token:token,
              id:id, 
            })
          }}>
          
          {/* Get User Photo  */}
         <Image source={{uri: "http://10.0.2.2:3333/api/v0.0.5/user/" + this.props.navigation.getParam("id","N0-ID") + "/photo"}} 
         style=
         {
           {
            top:25,
            left:3,
            width: 75,
            height: 75,
            position:"absolute",
            borderColor:"#000000",
            borderWidth:1,
           } 
        } />
        </TouchableOpacity>
        
          <TextInput
            style = {styles.PostChitMessageText}
            placeholder ="Post Chit Message!"
            onFocus={() => this.props.navigation.navigate('PostChitBig',
            {
              //Pass Paramaters through screens
              token:token,
              id,id,
            })}
          />

    </View>
     
    );
  }
}
export default MainSeeChits;
{/* //Style Sheet */}

const styles = StyleSheet.create({
container: 
{
  flex: 1,
},
image: 
{
  top:25,
  left:3,
  width: 75,
  height: 75,
  position:"absolute"
},
PostChitMessageText: 
{
   top:-600,
   left:80,
   color: "#121212",
   fontSize: 18,
   fontFamily: "arial-regular"
},
searchTextBox: 
{
   height:40,
   width:385,
   left:2,
   top:-620,
   borderWidth: 1,
   borderColor: '#009688',

},
searchText:
{
   top:5,
   color: "#AAAFB4",
   fontSize: 18,
   fontFamily: "arial-regular",
},

item: 
{
   height:"auto",
   backgroundColor: '#009688',
   top:130,
   width:390,
   fontSize: 18,
   fontFamily: "arial-regular"
}
});

# MAD ASSIGNMENT

# Setting Up

## Chitr Server

Open Node.JS command propt and navigate to the chittr server using cd **pathnamehere** then click enter

Once in that directory run the chittr server using `npm start`

You should get a message back saying **Listening on port: 3333**

## Main App
Open Node.JS command propt and navigate to the main app using cd **pathnamehere** then click enter

You should then proceed to install **Node Modules,** you can do this simply by running the command `npm install`

Once the node modules have been installed, still in that directory run the app using `npx react-native run-android`

You should get a message back saying 
**info Running jetifier to migrate libraries to AndroidX. You can disable it using "--no-jetifier" flag. Jetifier found 1172 file(s) to    forward-jetify. Using 12 workers... info JS server already running.    info Launching emulator... info Successfully launched emulator. info    Installing the app..**

It will then continue to Build the app, this will return **BUILD SUCCESSFUL**

# Using The Application

There are several ways of using Chittr, if you have an account you can login and continue to the app, usually this isnt the case when you first launch however so you will need to **Create An Account** you can do this by clicking the **Create An Account Button**, once successfully created this will then move you to the **Login Screen** where you can **proceed to Login.**

# Produced By: Rebecca Clarke (17032866) Version 1.5 2020
